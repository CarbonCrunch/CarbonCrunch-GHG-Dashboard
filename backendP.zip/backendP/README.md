# Flask OCR Application
This project is a Flask-based web application that processes uploaded images to extract text using Tesseract OCR. The extracted text is then used to populate form fields in the frontend application.


## Setup
### Step 1: Clone the repo and get into the backend branch 
```sh
cd backend
```

### Step 2: Set Up a Virtual Environment
Create a virtual environment and activate it:
#### MacOs:
```sh
python3 -m venv venv
source venv/bin/activate  
```
#### Windows:
```sh
python3 -m venv venv
venv\Scripts\activate
```

### Step 3: Install Dependencies
Install the required packages using pip:

```sh
pip install -r requirements.txt
```
### Step 4: Install Tesseract OCR
Tesseract OCR is required for text extraction. Install Tesseract OCR from here.
```sh
brew install tesseract
```
## Running the Application
Start the Flask application:

```sh
flask run
```